#include "../header/Transaction.h"
#include "../header/InfoArray.h"




    //Format
    // Date/Month/Year^Type of transaction^Amount^WalletName^Description

bool Output_Terminal(Transaction_Income);

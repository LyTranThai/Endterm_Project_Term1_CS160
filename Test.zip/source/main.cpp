#include <iostream>
#include "../header/User_Info.h"

using namespace std;

void Draw_Wallet_List(User_Info &user);
void Draw_Transaction_History(User_Info &user);
void Draw_Add_Transaction(User_Info &user);
void Draw_All_Transaction(User_Info &user);
void Draw_Recurring_Transaction_List(User_Info &user);
void RunApplication_Navigation(User_Info &user);

// MUST RUN TO INPUT CURRENCY DATA
//  int main()
//  {
//  //Create Currency List
//      Currency * Currency_Type=new Currency[3];
//      Input_Currency("currency",Currency_Type);
//      delete[]Currency_Type;
//      return 0;
//  }
#include <iostream>
#include <string>
#include <iomanip> // For formatting tables
#include <fstream> // For File I/O
#include <limits>  // For input cleaning

using namespace std;
void Draw_Add_Transaction(User_Info &user);
void Auto_Check_Recur(User_Info& user);


void drawMenu(User_Info &user) // ifstream& fin
{
    int window_width = 70;
    string userName = user.name;
    string currentWallet = user.default_Wallet->name;
    double currentRemainder = user.default_Wallet->remain;

    // 1. Header & User Info
    cout << string(window_width, '=') << endl;
    print_center("PERSONAL FINANCE MANAGER", ' ', window_width);
    cout << endl;
    cout << string(window_width, '=') << endl;

    // Display dynamic info (Name, Wallet, Remainder)
    cout
        << " User:      " << userName << "\n";
    cout << " Wallet:    " << currentWallet << "\n";
    cout << " Remainder: " << fixed << setprecision(2) << currentRemainder << "\n";
    cout << string(window_width, '-') << endl;
    cout << endl;
    cout << endl;
    //

    //
    //
    //
    //
    // total và wallet balance
    // total balance:
    long long total_balance = 0;
    for (int i = 0; i < user.wallet_count; i++)
    {

        if (user.Wallet_List[i] != nullptr)
        {
            total_balance += user.Wallet_List[i]->remain;
        }
    }

    // Hiển thị còn nhiêu
    cout << " " << string((int)50, '-') << endl;
    cout << " TOTAL BALANCE: " << right << setw(34) << total_balance << endl;
    cout << " " << string((int)50, '-') << endl;

    // Hiển thị ví :))
    cout << " Wallet Breakdown:\n";
    cout << " " << string((int)50, '-') << endl;
    if (user.wallet_count == 0)
    {
        cout << "   (No wallets created yet)\n";
    }
    else
    {
        for (int i = 0; i < user.wallet_count; i++)
        {
            if (user.Wallet_List[i] != nullptr)
            {

                cout << "   - " << left << setw(25) << user.Wallet_List[i]->name
                     << ": " << right << setw(18) << user.Wallet_List[i]->remain << endl;
            }
        }
    }
    //
    //
    //
    //

    cout << " " << string((int)50, '-') << endl;
    //
    cout << endl;
    cout << endl;

    // 2. Selectable Options
    cout << "1. Wallet List (Switch/View Wallets)\n";
    cout << "2. Transaction History\n";
    cout << "3. Add Transaction (Update)\n";
    cout << "4. Recurring Transaction List\n";
    cout << "5. Statistics & Reports\n";
    cout << "6. Add/Edit/Delete IN/EXP\n";
    cout << "7. Save Progress\n";
    cout << "8. Exit (Auto-Save & End)\n";
    cout << string(window_width, '-') << endl;
    cout << "Select option: ";
}

void Draw_Wallet_List(User_Info &user)
{
    int window_width = 70;
    int choice;
    bool checkk=true;
    while (checkk)
    {
        clearScreen();
        // Header
        cout << string(window_width, '=') << endl;
        print_center("WALLET MANAGEMENT", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;

        user.Show_Wallet_List(); // Hiển thị danh sách

        // Menu con
        cout << "1. Add New Wallet\n";
        cout << "2. Edit Wallet\n";
        cout << "3. Delete Wallet\n";
        cout << "4. Switch default Wallet\n";
        cout << "0. Back to Main Menu\n";
        cout << string(window_width, '-') << endl;
        bool check=true;
        string input;
        while(check)
        {
        cout << "Select option: ";
        cin>>input;
    
        if (!isValidInt(input))
        {
            Clear_Buffer();
            cout << "Error: Please Input an valid ID.\n";
            cout << "Press enter to retype...";
            cin.get();
            Clear_Buffer();
            ClearLines(3);
        }
        else
        {
            choice=stoi(input);
            check=false;
        }
        }
        // Xử lý nhập liệu
        // if (!Input_Choice(choice))
        // {
        //     continue;
        // }

        switch (choice)
        {
        case 1:
            user.Add_Wallet();
            pause();
            break;
        case 2:
            user.Edit_Wallet();
            break; // Pause đã có bên trong hàm
        case 3:
            user.Delete_Wallet();
            break;
        case 4:
            user.Switch_Wallet();
            break;
        case 0:
            return; // Thoát vòng lặp, quay về Menu chính
        default:
            cout << "\n[!] Invalid option.\n";
            pause();
            break;
        }
    }
}

// 1.Change Wallet 2. back
void Draw_Transaction_History(User_Info &user)
{
    int window_width = 70;
    int choice;
    while (true)
    {
        clearScreen();

        // 1. Header & User Info
        cout << string(window_width, '=') << endl;
        print_center("PERSONAL FINANCE MANAGER", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;
        print_center("TRANSACTION HISTORY", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;

        user.Show_Transaction_History();

        // 2. Selectable Options
        cout << "1. Add Transaction\n";
        cout << "2. Show all Transaction\n";
        cout << "0. Back to menu\n";
        cout << string(window_width, '-') << endl;
        cout << "Select option: ";
        if (!Input_Choice(choice))
        {
            continue;
        }
        switch (choice)
        {
        case 1:
            Draw_Add_Transaction(user);
            break;
        case 2:
            Draw_All_Transaction(user);
            break;
        case 0:
            return;
        default:
            cout << "\n[!] Invalid option.\n";
            pause();
            break;
        }
    }
}
void Draw_Add_Transaction(User_Info &user)
{
    int window_width = 70;
    int choice;
    while (true)
    {
        clearScreen();
        // 1. Header & User Info
        cout << string(window_width, '=') << endl;
        print_center("PERSONAL FINANCE MANAGER", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;
        print_center("ADD TRANSACTION", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;
        user.Show_Transaction_History();
        // 2. Selectable Options
        cout << "1. Add Income Transaction\n";
        cout << "2. Add Expense Transaction\n";
        cout << "0. Back to menu\n";
        cout << string(window_width, '=') << endl;
        cout << "Select option: ";
        if (!Input_Choice(choice))
        {
            continue;
        }
        switch (choice)
        {
        case 1:
            user.Add_Income_Transaction();
            break;
        case 2:
            user.Add_Expense_Transaction();
            break;
        case 0:
            return;
        default:
            cout << "\n[!] Invalid option.\n";
            pause();
            //Thiếu xóa
            break;
        }
    }
}

void Draw_All_Transaction(User_Info &user)
{
    int window_width = 70;
    int choice;
    while (true)
    {
        clearScreen();
        // 1. Header & User Info
        cout << string(window_width, '=') << endl;
        print_center("PERSONAL FINANCE MANAGER", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;
        print_center("ADD TRANSACTION", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;
        user.Show_All_Transaction_History();
        // 2. Selectable Options
        cout << "0. Back to menu\n";
        cout << string(window_width, '=') << endl;
        cout << "Select option: ";
        if (!Input_Choice(choice))
        {
            continue;
        }
        switch (choice)
        {
        case 0:
            return;
        default:
            cout << "\n[!] Invalid option.\n";
            pause();
            break;
        }
    }
}



void Draw_Recurring_Transaction_List(User_Info &user)
{
    int window_width = 70;
    int choice;
    while (true)
    {
        clearScreen();
        // 1. Header & User Info
        cout << string(window_width, '=') << endl;
        print_center("PERSONAL FINANCE MANAGER", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;
        print_center("RECURRING TRANSACTION LIST", ' ', window_width);
        cout << endl;
        cout << string(window_width, '=') << endl;
        user.Show_Recurring_Transaction_List();
        // 2. Selectable Options
        cout << "1. Add Income Recurring Transaction\n";
        cout << "2. Add Expense Recurring Transaction\n";
        cout << "3. Stop Income Recurring Transaction\n";
        cout << "4. Stop Expense Recurring Transaction\n";
        cout << "0. Back to menu\n";
        cout << "-------------------------------------------------\n";
        cout << "Select option: ";
        if (!Input_Choice(choice))
        {
            continue;
        }
        switch (choice)
        {
        case 1:
            user.Add_Recur_Income_Transaction();
            break;
        case 2:
            user.Add_Recur_Expense_Transaction();
            break;
        case 3:
            clearScreen();
            user.Show_Recurring_Transaction_List(user.Recurring_Transaction_Income_List);
            user.Stop_recur_trans(user.Recurring_Transaction_Income_List[0]);
            break;
        case 4:
            clearScreen();
            user.Show_Recurring_Transaction_List(user.Recurring_Transaction_Expense_List);
            user.Stop_recur_trans(user.Recurring_Transaction_Expense_List[0]);
            break;
        case 0:
            return;
        default:
            cout << "\n[!] Invalid option.\n";
            pause();
            break;
        }
    }
}
bool Input_Choice(int &choice);
void Input_User_Info_Textfile(string filename);

// Income Management:
// ▪ Users enter information for an income transaction.
// ▪ Required Data:
// ▪ Date: The date the transaction is executed.
// ▪ Income Source: The system stores the Source ID for logic processing but displays the
// Source Name on the user interface.
// ▪ Amount: The value of the income.
// ▪ Wallet: The system stores the Wallet ID but displays the Wallet Name.
// ▪ Description: Detailed notes for the income.
// o Expense Management:
// ▪ Users enter information for expense transactions.
// ▪ Required Data:
// ▪ Date: The date the transaction is executed.
// ▪ Income Source: the system stores the Category ID but displays the Category Name.
// ▪ Amount: The value of the expense.
// ▪ Wallet: The system stores the Wallet ID but displays the Wallet Name.
// ▪ Description: Detailed notes for the expense.

// Support automation for entering frequently recurring income or expenses.
// o Recurring Configuration: Allow pre-creation of recurring transactions on Monthly basis.
// o Applicable Time:
// ▪ Start Date: Required.
// ▪ End Date: Optional (Can be left blank if the transaction recurs indefinitely).
// o Mechanism: When the user opens the application, the system checks and adds the transaction for
// the current month if the conditions are met, ensuring that the transaction is not added again if it
// already exists for the current cycle.
void RunApplication_Navigation(User_Info &user)
{
    ofstream fout;
    while (true)
    {
        int choice;
        clearScreen();
        drawMenu(user);
        if (!Input_Choice(choice))
        {
            cout << "\n[!] Invalid input. Please enter a number.\n";
            pause();
            continue;
        }
        switch (choice)
        {
        case 1:
            Draw_Wallet_List(user);
            break;
        case 2:
            Draw_Transaction_History(user);
            break;
        case 3:
            Draw_Add_Transaction(user);
            break;
        case 4:
            Draw_Recurring_Transaction_List(user);
            break;
        case 5:
            user.Draw_Statistics_Menu();
            break;
        case 6:
            user.Draw_MasterData_Menu(); // tutu, nay de add edit delete a
            break;
        case 7:
            Auto_Check_Recur(user);
            fout.open("../UserData/" + user.name + ".bin", ios::binary | ios::trunc);
            user.SaveToBinary(fout);
            cout << "\nSaving progress...\n";
            fout.close();
            cout << "Progress saved successfully.\n";
            pause();
            break;
        case 8:
            fout.open("../UserData/" + user.name + ".bin", ios::binary | ios::trunc);
            user.SaveToBinary(fout);
            cout << "\nSaving progress...\n";
            fout.close();
            cout << "Progress saved successfully.\n";
            cout << "\nExiting application. Goodbye!\n";
            return;
        default:
            cout << "\n[!] Option not found.\n";
            pause();
            break;
        }
    }
}

void Auto_Check_Recur(User_Info& user)

{
    
        // 4. CHECK RECURRING TRANSACTIONS (Requirement: Check on startup)
        Date today;
        GetCurrentDate(today); // Assumed function from Date.h

        bool auto_updates = false;

        // Check Recurring Expenses
        for (int i = 0; i < user.recur_trans_expense_count; i++)
        {
            if (user.check_recur_trans(user.Recurring_Transaction_Expense_List[i], today))
            {
                auto_updates = true;
            }
        }
        cout<<"Done Check Recurring Expenses"<<endl;
        // Check Recurring Incomes
        for (int i = 0; i < user.recur_trans_income_count; i++)
        {
            if (user.check_recur_trans(user.Recurring_Transaction_Income_List[i], today))
            {
                auto_updates = true;
            }
        }
        cout<<"Done Check Recurring Incomes"<<endl;

        if (auto_updates)
        {
            cout << " [!] Automatic recurring transactions have been generated for this month.\n";
            cout << "     Press Enter to continue...";
            std::cin.get();
        }
}

int main()
{
    // 1. Setup Interface
    clearScreen();
    cout << endl;
    cout << "=================================================\n";
    cout << "              FINANCIAL TRACKER APP              \n";
    cout << "=================================================\n";
    cout << "Type in your name (no spaces): ";

    string name;
    std::cin >> name;
    Clear_Buffer(); // Clear newline left by cin >> name

    // 2. Define File Path
    // Ensure the "UserData" folder exists relative to your exe, or create it manually.
    string filename = "../UserData/" + name + ".bin";

    User_Info user; // Constructor runs here (initializes Default Wallet, Unknown Categories)

    // 3. Check if file exists
    ifstream fin(filename, ios::binary);

    if (fin.is_open())
    {
        cout << "\n [!] Welcome back, " << name << "! Loading your data...\n";

        // LOAD DATA
        user.LoadFromBinary(fin);
        cout<<"Load Success"<<endl;
        fin.close();

        // 4. CHECK RECURRING TRANSACTIONS (Requirement: Check on startup)
        Auto_Check_Recur(user);
    }
    else
    {
        cout << "\n [!] New user detected. Creating profile for " << name << "...\n";
        user.name = name;

        // SAVE DEFAULTS IMMEDIATELY
        // This ensures the file exists with the default "Default" wallet
        ofstream fout(filename, ios::binary);
        if (fout.is_open())
        {
            user.SaveToBinary(fout);
            fout.close();
            cout << " [!] Profile created successfully.\n";
        }
        else
        {
            cerr << " [Error] Could not create file at: " << filename << endl;
            cerr << "         Please ensure the folder '../UserData' exists.\n";
            system("pause");
            return 1;
        }

        cout << " Press Enter to start...";
        std::cin.get();
    }

    // 5. Run Application
    RunApplication_Navigation(user);

    return 0;
}